import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    public void testContactCreatedSuccessfully() {
        Contact contact = new Contact("1234567890", "Richard", "Savage", "1234567890", "123 Main Street");

        assertEquals("1234567890", contact.getContactId());
        assertEquals("Richard", contact.getFirstName());
        assertEquals("Savage", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main Street", contact.getAddress());
    }

    @Test
    public void testContactIdCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "Richard", "Savage", "1234567890", "123 Main Street");
        });
    }

    @Test
    public void testContactIdCannotBeLongerThanTenCharacters() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "Richard", "Savage", "1234567890", "123 Main Street");
        });
    }

    @Test
    public void testFirstNameCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", null, "Savage", "1234567890", "123 Main Street");
        });
    }

    @Test
    public void testFirstNameCannotBeLongerThanTenCharacters() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "RichardLong", "Savage", "1234567890", "123 Main Street");
        });
    }

    @Test
    public void testLastNameCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Richard", null, "1234567890", "123 Main Street");
        });
    }

    @Test
    public void testLastNameCannotBeLongerThanTenCharacters() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Richard", "SavageLong1", "1234567890", "123 Main Street");
        });
    }

    @Test
    public void testPhoneCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Richard", "Savage", null, "123 Main Street");
        });
    }

    @Test
    public void testPhoneMustBeExactlyTenDigits() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Richard", "Savage", "12345", "123 Main Street");
        });
    }

    @Test
    public void testPhoneMustOnlyContainDigits() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Richard", "Savage", "12345abcde", "123 Main Street");
        });
    }

    @Test
    public void testAddressCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Richard", "Savage", "1234567890", null);
        });
    }

    @Test
    public void testAddressCannotBeLongerThanThirtyCharacters() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Richard", "Savage", "1234567890", "123 Main Street Apartment 12345");
        });
    }

    @Test
    public void testSetFirstNameRejectsInvalidValue() {
        Contact contact = new Contact("12345", "Richard", "Savage", "1234567890", "123 Main Street");

        assertThrows(IllegalArgumentException.class, () -> {
            contact.setFirstName(null);
        });
    }

    @Test
    public void testSetPhoneRejectsInvalidValue() {
        Contact contact = new Contact("12345", "Richard", "Savage", "1234567890", "123 Main Street");

        assertThrows(IllegalArgumentException.class, () -> {
            contact.setPhone("12345");
        });
    }
}
