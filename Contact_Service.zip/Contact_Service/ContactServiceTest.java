import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    @Test
    public void testAddContactSuccessfully() {
        ContactService service = new ContactService();
        Contact contact = new Contact("12345", "Richard", "Savage", "1234567890", "123 Main Street");

        service.addContact(contact);

        assertEquals(contact, service.getContact("12345"));
    }

    @Test
    public void testAddContactWithDuplicateIdThrowsException() {
        ContactService service = new ContactService();
        Contact contactOne = new Contact("12345", "Richard", "Savage", "1234567890", "123 Main Street");
        Contact contactTwo = new Contact("12345", "John", "Smith", "0987654321", "456 Oak Street");

        service.addContact(contactOne);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(contactTwo);
        });
    }

    @Test
    public void testAddNullContactThrowsException() {
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(null);
        });
    }

    @Test
    public void testDeleteContactSuccessfully() {
        ContactService service = new ContactService();
        Contact contact = new Contact("12345", "Richard", "Savage", "1234567890", "123 Main Street");

        service.addContact(contact);
        service.deleteContact("12345");

        assertThrows(IllegalArgumentException.class, () -> {
            service.getContact("12345");
        });
    }

    @Test
    public void testDeleteContactThatDoesNotExistThrowsException() {
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteContact("99999");
        });
    }

    @Test
    public void testUpdateFirstNameSuccessfully() {
        ContactService service = new ContactService();
        Contact contact = new Contact("12345", "Richard", "Savage", "1234567890", "123 Main Street");

        service.addContact(contact);
        service.updateFirstName("12345", "Rich");

        assertEquals("Rich", service.getContact("12345").getFirstName());
    }

    @Test
    public void testUpdateLastNameSuccessfully() {
        ContactService service = new ContactService();
        Contact contact = new Contact("12345", "Richard", "Savage", "1234567890", "123 Main Street");

        service.addContact(contact);
        service.updateLastName("12345", "Smith");

        assertEquals("Smith", service.getContact("12345").getLastName());
    }

    @Test
    public void testUpdatePhoneSuccessfully() {
        ContactService service = new ContactService();
        Contact contact = new Contact("12345", "Richard", "Savage", "1234567890", "123 Main Street");

        service.addContact(contact);
        service.updatePhone("12345", "0987654321");

        assertEquals("0987654321", service.getContact("12345").getPhone());
    }

    @Test
    public void testUpdateAddressSuccessfully() {
        ContactService service = new ContactService();
        Contact contact = new Contact("12345", "Richard", "Savage", "1234567890", "123 Main Street");

        service.addContact(contact);
        service.updateAddress("12345", "456 Oak Street");

        assertEquals("456 Oak Street", service.getContact("12345").getAddress());
    }

    @Test
    public void testUpdateContactThatDoesNotExistThrowsException() {
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateFirstName("99999", "Rich");
        });
    }

    @Test
    public void testUpdateFirstNameWithInvalidValueThrowsException() {
        ContactService service = new ContactService();
        Contact contact = new Contact("12345", "Richard", "Savage", "1234567890", "123 Main Street");

        service.addContact(contact);

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateFirstName("12345", "RichardLong");
        });
    }

    @Test
    public void testUpdatePhoneWithInvalidValueThrowsException() {
        ContactService service = new ContactService();
        Contact contact = new Contact("12345", "Richard", "Savage", "1234567890", "123 Main Street");

        service.addContact(contact);

        assertThrows(IllegalArgumentException.class, () -> {
            service.updatePhone("12345", "12345");
        });
    }
}
